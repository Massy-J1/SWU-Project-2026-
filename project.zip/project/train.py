#!/usr/bin/env python3
"""Train the first smishing baseline model."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from smishing_detector.tfidf_model import TfidfCentroidModel, evaluate, normalize_label, stratified_split


def load_records(paths: list[Path]) -> list[tuple[str, str]]:
    records: list[tuple[str, str]] = []
    seen = set()

    for path in paths:
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            if not reader.fieldnames or "text" not in reader.fieldnames or "label" not in reader.fieldnames:
                raise ValueError(f"{path} must have text,label columns")
            for row in reader:
                text = (row.get("text") or "").strip()
                label = normalize_label(row.get("label") or "")
                if not text:
                    continue
                key = (text, label)
                if key in seen:
                    continue
                seen.add(key)
                records.append((text, label))

    if len(records) < 4:
        raise ValueError("not enough records")
    return records


def main() -> int:
    parser = argparse.ArgumentParser(description="Train TF-IDF smishing baseline")
    parser.add_argument(
        "--data",
        nargs="+",
        type=Path,
        default=[Path("data/smishing_seed_ko.csv")],
        help="CSV file(s) with text,label columns",
    )
    parser.add_argument("--model-out", type=Path, default=Path("artifacts/smishing_tfidf_model.json"))
    parser.add_argument("--metrics-out", type=Path, default=Path("reports/metrics.json"))
    parser.add_argument("--threshold", type=float, default=0.55)
    parser.add_argument("--test-size", type=float, default=0.30)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--min-df", type=int, default=1)
    args = parser.parse_args()

    records = load_records(args.data)
    train_records, test_records = stratified_split(records, test_size=args.test_size, seed=args.seed)
    model = TfidfCentroidModel.train(train_records, min_df=args.min_df, threshold=args.threshold)
    metrics = evaluate(model, test_records)
    metrics.update(
        {
            "n_total": len(records),
            "n_train": len(train_records),
            "n_test": len(test_records),
            "data_files": [str(path) for path in args.data],
            "threshold": args.threshold,
        }
    )

    args.model_out.parent.mkdir(parents=True, exist_ok=True)
    args.metrics_out.parent.mkdir(parents=True, exist_ok=True)
    model.save(args.model_out)
    args.metrics_out.write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"saved model: {args.model_out}")
    print(f"saved metrics: {args.metrics_out}")
    print(
        "accuracy={accuracy:.4f} precision={precision:.4f} recall={recall:.4f} f1={f1:.4f}".format(
            **metrics
        )
    )
    print("confusion_matrix:", json.dumps(metrics["confusion_matrix"], ensure_ascii=False))
    if metrics["errors"]:
        print("errors are stored by hash only in reports/metrics.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
