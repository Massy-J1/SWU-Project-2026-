package kr.ac.swu.smishing

import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

data class SmsRiskResult(
    val label: String,
    val riskScore: Double,
    val reasons: List<String>
) {
    val isRisky: Boolean
        get() = label == "smishing"
}

class SmsRiskClient(
    private val endpoint: String = "http://10.0.2.2:8000/predict"
) {
    fun predict(message: String): SmsRiskResult {
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 3000
            readTimeout = 3000
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true
        }

        val payload = JSONObject().put("message", message).toString()
        OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { writer ->
            writer.write(payload)
        }

        val responseText = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        val json = JSONObject(responseText)
        val reasonsJson = json.optJSONArray("reasons") ?: JSONArray()
        val reasons = buildList {
            for (i in 0 until reasonsJson.length()) add(reasonsJson.getString(i))
        }

        return SmsRiskResult(
            label = json.getString("label"),
            riskScore = json.getDouble("risk_score"),
            reasons = reasons
        )
    }
}
