package kr.ac.swu.smishingguard;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;

public class MmsReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Telephony.Sms.Intents.WAP_PUSH_RECEIVED_ACTION.equals(intent.getAction())) {
            return;
        }

        PendingResult pendingResult = goAsync();
        new Thread(() -> {
            try {
                Thread.sleep(3500L);
                String text = MmsReader.readLatestText(context);
                if (!text.trim().isEmpty()) {
                    TfidfDetector detector = TfidfDetector.fromAssets(context);
                    DetectionResult result = detector.analyze(text);
                    if (result.isRisky()) {
                        SmsAlertNotifier.notifyRisk(context, result);
                    }
                }
            } catch (Exception ignored) {
            } finally {
                pendingResult.finish();
            }
        }).start();
    }
}
