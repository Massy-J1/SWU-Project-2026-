package kr.ac.swu.smishingguard;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

final class SmsAlertNotifier {
    private static final String CHANNEL_ID = "smishing_guard_alerts";
    private static final int NOTIFICATION_ID = 20260627;

    private SmsAlertNotifier() {
    }

    static void notifyRisk(Context context, DetectionResult result) {
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        ensureChannel(manager);

        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String reason = result.reasons.isEmpty() ? "위험 특징 감지" : result.reasons.get(0);
        String content = "위험점수 " + String.format(java.util.Locale.ROOT, "%.2f", result.riskScore)
                + " · " + reason;

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);

        Notification notification = builder
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("스미싱 의심 문자 감지")
                .setContentText(content)
                .setStyle(new Notification.BigTextStyle().bigText(content + "\n공식 앱/사이트에서 직접 확인하세요."))
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setPriority(Notification.PRIORITY_HIGH)
                .setDefaults(Notification.DEFAULT_ALL)
                .build();

        manager.notify(NOTIFICATION_ID, notification);
    }

    static void ensureChannel(NotificationManager manager) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "스미싱 경고",
                NotificationManager.IMPORTANCE_HIGH
        );
        channel.setDescription("의심 문자 수신 시 자동 경고");
        manager.createNotificationChannel(channel);
    }
}
