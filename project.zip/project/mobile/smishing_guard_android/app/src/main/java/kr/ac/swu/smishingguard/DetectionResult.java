package kr.ac.swu.smishingguard;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public final class DetectionResult {
    public final String label;
    public final double riskScore;
    public final double modelProbability;
    public final double heuristicScore;
    public final double threshold;
    public final String messageHash;
    public final List<String> reasons;
    public final Map<String, Boolean> flags;
    public final int urlCount;

    DetectionResult(
            String label,
            double riskScore,
            double modelProbability,
            double heuristicScore,
            double threshold,
            String messageHash,
            List<String> reasons,
            Map<String, Boolean> flags,
            int urlCount
    ) {
        this.label = label;
        this.riskScore = riskScore;
        this.modelProbability = modelProbability;
        this.heuristicScore = heuristicScore;
        this.threshold = threshold;
        this.messageHash = messageHash;
        this.reasons = Collections.unmodifiableList(reasons);
        this.flags = Collections.unmodifiableMap(flags);
        this.urlCount = urlCount;
    }

    public boolean isRisky() {
        return "smishing".equals(label);
    }
}
