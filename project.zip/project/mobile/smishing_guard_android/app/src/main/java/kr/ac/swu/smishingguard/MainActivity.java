package kr.ac.swu.smishingguard;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PERMISSION_REQUEST_AUTO_SMS = 27;
    private static final String SAMPLE_RISK =
            "[정부24] 피해 지원금 신청 대상. 오늘 마감, 신청서 작성 http://gov24-benefit.example";
    private static final String SAMPLE_SAFE =
            "[학교] 내일 연구활동은 오후 2시에 시작합니다. 필기도구를 준비하세요.";

    private EditText messageInput;
    private TextView verdictView;
    private TextView scoreView;
    private TextView reasonView;
    private TextView autoStatusView;
    private LinearLayout resultCard;
    private Button copyButton;
    private Button autoButton;
    private TfidfDetector detector;
    private String lastResultText = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#F7F8FA"));
        try {
            detector = TfidfDetector.fromAssets(this);
        } catch (Exception e) {
            detector = null;
        }
        buildUi();
        if (detector == null) {
            setErrorState("모델 파일을 불러오지 못했습니다.");
        }
    }

    private void buildUi() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(Color.parseColor("#F7F8FA"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(24));
        scrollView.addView(root, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT
        ));

        TextView title = text("Smishing Guard", 28, "#172026", true);
        root.addView(title);

        TextView subtitle = text("오프라인 문자 위험 분석", 15, "#5F6B73", false);
        subtitle.setPadding(0, dp(2), 0, dp(18));
        root.addView(subtitle);

        messageInput = new EditText(this);
        messageInput.setMinLines(6);
        messageInput.setGravity(Gravity.TOP | Gravity.START);
        messageInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        messageInput.setTextSize(16);
        messageInput.setTextColor(Color.parseColor("#172026"));
        messageInput.setHint("분석할 문자 내용을 붙여넣기");
        messageInput.setHintTextColor(Color.parseColor("#8A949C"));
        messageInput.setPadding(dp(14), dp(12), dp(14), dp(12));
        messageInput.setBackground(box("#FFFFFF", "#CDD4DA", 8));
        root.addView(messageInput, matchWrap());

        LinearLayout sampleRow = new LinearLayout(this);
        sampleRow.setOrientation(LinearLayout.HORIZONTAL);
        sampleRow.setPadding(0, dp(12), 0, 0);
        root.addView(sampleRow, matchWrap());

        Button riskSample = button("위험 예시", "#F0DADA", "#8E2F2F", "#D79B9B");
        riskSample.setOnClickListener(v -> messageInput.setText(SAMPLE_RISK));
        sampleRow.addView(riskSample, weightWrap(1));

        SpaceView gap = new SpaceView(this, dp(8), 1);
        sampleRow.addView(gap);

        Button safeSample = button("정상 예시", "#DCECE7", "#0E6F5B", "#A8CCC1");
        safeSample.setOnClickListener(v -> messageInput.setText(SAMPLE_SAFE));
        sampleRow.addView(safeSample, weightWrap(1));

        Button analyzeButton = button("분석하기", "#172026", "#FFFFFF", "#172026");
        LinearLayout.LayoutParams analyzeParams = matchWrap();
        analyzeParams.setMargins(0, dp(12), 0, 0);
        analyzeButton.setMinHeight(dp(52));
        analyzeButton.setOnClickListener(v -> analyze());
        root.addView(analyzeButton, analyzeParams);

        LinearLayout autoCard = new LinearLayout(this);
        autoCard.setOrientation(LinearLayout.VERTICAL);
        autoCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        autoCard.setBackground(box("#FFFFFF", "#D8DEE4", 8));
        LinearLayout.LayoutParams autoParams = matchWrap();
        autoParams.setMargins(0, dp(14), 0, 0);
        root.addView(autoCard, autoParams);

        TextView autoTitle = text("자동 문자 감지", 18, "#172026", true);
        autoCard.addView(autoTitle);

        autoStatusView = text("", 14, "#5F6B73", false);
        autoStatusView.setPadding(0, dp(4), 0, dp(10));
        autoCard.addView(autoStatusView);

        autoButton = button("자동 감지 권한 켜기", "#FFFFFF", "#172026", "#C8D0D6");
        autoButton.setOnClickListener(v -> requestAutoDetectionPermissions());
        autoCard.addView(autoButton, matchWrap());

        resultCard = new LinearLayout(this);
        resultCard.setOrientation(LinearLayout.VERTICAL);
        resultCard.setPadding(dp(16), dp(16), dp(16), dp(16));
        resultCard.setBackground(box("#FFFFFF", "#D8DEE4", 8));
        LinearLayout.LayoutParams resultParams = matchWrap();
        resultParams.setMargins(0, dp(18), 0, 0);
        root.addView(resultCard, resultParams);

        verdictView = text("대기 중", 22, "#172026", true);
        resultCard.addView(verdictView);

        scoreView = text("문자를 입력하고 분석하기를 누르세요.", 15, "#5F6B73", false);
        scoreView.setPadding(0, dp(6), 0, dp(10));
        resultCard.addView(scoreView);

        reasonView = text("근거가 여기에 표시됩니다.", 15, "#344048", false);
        reasonView.setLineSpacing(0, 1.12f);
        resultCard.addView(reasonView);

        copyButton = button("결과 복사", "#FFFFFF", "#172026", "#C8D0D6");
        copyButton.setEnabled(false);
        LinearLayout.LayoutParams copyParams = matchWrap();
        copyParams.setMargins(0, dp(12), 0, 0);
        copyButton.setOnClickListener(v -> copyResult());
        resultCard.addView(copyButton, copyParams);

        TextView privacy = text("원문은 기기 밖으로 전송되지 않습니다.", 13, "#6E7880", false);
        privacy.setGravity(Gravity.CENTER);
        privacy.setPadding(0, dp(14), 0, 0);
        root.addView(privacy, matchWrap());

        setContentView(scrollView);
        updateAutoStatus();
    }

    private void analyze() {
        if (detector == null) {
            setErrorState("모델 파일을 불러오지 못했습니다.");
            return;
        }
        String message = messageInput.getText().toString().trim();
        if (message.isEmpty()) {
            Toast.makeText(this, "문자 내용을 입력하세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        DetectionResult result = detector.analyze(message);
        int bg = result.isRisky() ? Color.parseColor("#FFF1F1") : Color.parseColor("#EEF8F4");
        int border = result.isRisky() ? Color.parseColor("#E5A2A2") : Color.parseColor("#B2D8C8");
        int main = result.isRisky() ? Color.parseColor("#8E2F2F") : Color.parseColor("#0E6F5B");

        resultCard.setBackground(box(color(bg), color(border), 8));
        verdictView.setText(result.isRisky() ? "위험: 스미싱 의심" : "정상 가능성 높음");
        verdictView.setTextColor(main);
        scoreView.setText(String.format(
                Locale.ROOT,
                "위험점수 %.2f · 모델 %.2f · 규칙 %.2f · 임계값 %.2f",
                result.riskScore,
                result.modelProbability,
                result.heuristicScore,
                result.threshold
        ));

        StringBuilder reasons = new StringBuilder();
        if (result.reasons.isEmpty()) {
            reasons.append("근거: 강한 위험 특징 없음");
        } else {
            reasons.append("근거\n");
            for (String reason : result.reasons) {
                reasons.append("• ").append(reason).append("\n");
            }
        }
        reasons.append("\nSHA-256\n").append(result.messageHash);
        if (result.isRisky()) {
            reasons.append("\n\n경고: 출처가 불분명한 링크를 열지 말고 공식 앱/사이트에서 직접 확인하세요.");
        }

        lastResultText = verdictView.getText() + "\n" + scoreView.getText() + "\n" + reasons;
        reasonView.setText(reasons.toString().trim());
        copyButton.setEnabled(true);
    }

    private void copyResult() {
        if (lastResultText.isEmpty()) return;
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("smishing-result", lastResultText));
        Toast.makeText(this, "결과를 복사했습니다.", Toast.LENGTH_SHORT).show();
    }

    private void requestAutoDetectionPermissions() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            updateAutoStatus();
            Toast.makeText(this, "자동 감지가 켜져 있습니다.", Toast.LENGTH_SHORT).show();
            return;
        }

        java.util.ArrayList<String> permissions = new java.util.ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.RECEIVE_SMS);
        }
        if (checkSelfPermission(Manifest.permission.RECEIVE_MMS) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.RECEIVE_MMS);
        }
        if (checkSelfPermission(Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.READ_SMS);
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS);
        }

        if (permissions.isEmpty()) {
            updateAutoStatus();
            Toast.makeText(this, "자동 감지가 이미 켜져 있습니다.", Toast.LENGTH_SHORT).show();
            return;
        }
        requestPermissions(permissions.toArray(new String[0]), PERMISSION_REQUEST_AUTO_SMS);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_AUTO_SMS) {
            updateAutoStatus();
            Toast.makeText(
                    this,
                    hasAutoDetectionPermissions() ? "새 문자 자동 감지가 켜졌습니다." : "권한이 필요합니다.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private boolean hasAutoDetectionPermissions() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        boolean sms = checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED;
        boolean mms = checkSelfPermission(Manifest.permission.RECEIVE_MMS) == PackageManager.PERMISSION_GRANTED;
        boolean readSms = checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED;
        boolean notification = Build.VERSION.SDK_INT < 33
                || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        return sms && mms && readSms && notification;
    }

    private void updateAutoStatus() {
        if (autoStatusView == null || autoButton == null) return;
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) SmsAlertNotifier.ensureChannel(manager);
        if (hasAutoDetectionPermissions()) {
            autoStatusView.setText("켜짐 · 새 SMS/MMS가 도착하면 오프라인으로 분석하고 위험 문자만 알림을 띄웁니다.");
            autoStatusView.setTextColor(Color.parseColor("#0E6F5B"));
            autoButton.setText("권한 켜짐");
            autoButton.setEnabled(false);
        } else {
            autoStatusView.setText("꺼짐 · 자동 감지를 쓰려면 SMS/MMS 수신 권한, 문자 읽기 권한, 알림 권한을 허용하세요.");
            autoStatusView.setTextColor(Color.parseColor("#8E2F2F"));
            autoButton.setText("자동 감지 권한 켜기");
            autoButton.setEnabled(true);
        }
    }

    private void setErrorState(String message) {
        if (resultCard == null) return;
        resultCard.setBackground(box("#FFF1F1", "#E5A2A2", 8));
        verdictView.setText("오류");
        verdictView.setTextColor(Color.parseColor("#8E2F2F"));
        scoreView.setText(message);
        reasonView.setText("assets/smishing_tfidf_model.json 파일을 확인하세요.");
    }

    private TextView text(String value, int sp, String color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(Color.parseColor(color));
        view.setIncludeFontPadding(true);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private Button button(String label, String bg, String fg, String border) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(15);
        button.setAllCaps(false);
        button.setTextColor(Color.parseColor(fg));
        button.setBackground(box(bg, border, 8));
        button.setMinHeight(dp(44));
        button.setPadding(dp(10), 0, dp(10), 0);
        return button;
    }

    private GradientDrawable box(String fill, String stroke, int radiusDp) {
        return box(Color.parseColor(fill), Color.parseColor(stroke), radiusDp);
    }

    private GradientDrawable box(int fill, int stroke, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radiusDp));
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private String color(int color) {
        return String.format(Locale.ROOT, "#%06X", (0xFFFFFF & color));
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
    }

    private LinearLayout.LayoutParams weightWrap(int weight) {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static final class SpaceView extends View {
        SpaceView(Context context, int width, int height) {
            super(context);
            setLayoutParams(new LinearLayout.LayoutParams(width, height));
        }
    }
}
