package kr.ac.swu.smishingguard;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

final class TextFeatures {
    String messageHash;
    int urlCount;
    final Map<String, Boolean> flags = new LinkedHashMap<>();
    final List<String> reasons = new ArrayList<>();
    final List<String> modelTokens = new ArrayList<>();
}
