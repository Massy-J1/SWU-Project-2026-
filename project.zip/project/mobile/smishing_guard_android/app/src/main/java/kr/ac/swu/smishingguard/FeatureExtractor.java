package kr.ac.swu.smishingguard;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class FeatureExtractor {
    static final Pattern URL_PATTERN = Pattern.compile(
            "\\b(?:https?://|www\\.)[^\\s<>\"']+|\\b(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+(?:[a-z]{2,})(?:/[^\\s<>\"']*)?",
            Pattern.CASE_INSENSITIVE
    );

    private static final Pattern PHONE_PATTERN = Pattern.compile("(?<!\\d)(?:0\\d{1,2}[-.\\s]?\\d{3,4}[-.\\s]?\\d{4}|1[0-9]{2,3}[-.\\s]?\\d{4})(?!\\d)");
    private static final Pattern AMOUNT_PATTERN = Pattern.compile("(?:\\d{1,3}(?:,\\d{3})+|\\d+)\\s*(?:원|만원|억원|달러|USD|KRW)|[₩$]\\s*\\d+");

    private static final List<String> ORG_KEYWORDS = Arrays.asList(
            "정부24", "정부", "경찰청", "검찰", "법원", "국세청", "관세청", "금융감독원", "금감원",
            "건강보험", "공단", "우체국", "택배", "cj대한통운", "쿠팡", "국민은행", "신한은행",
            "농협", "카카오", "네이버", "통신사", "카드사"
    );
    private static final List<String> URGENCY_KEYWORDS = Arrays.asList(
            "긴급", "즉시", "오늘", "당일", "마감", "기한", "최종", "정지", "차단", "압류",
            "연체", "미납", "경고", "확인필", "보류", "제한"
    );
    private static final List<String> ACTION_KEYWORDS = Arrays.asList(
            "클릭", "접속", "확인", "입력", "인증", "다운로드", "설치", "열람", "조회", "신청",
            "업데이트", "재등록", "납부", "환급", "결제", "취소"
    );
    private static final List<String> APP_INSTALL_KEYWORDS = Arrays.asList(
            "apk", "앱설치", "앱 설치", "설치파일", "보안앱", "원격제어", "원격 제어", "업데이트 설치"
    );
    private static final List<String> PII_KEYWORDS = Arrays.asList(
            "주민번호", "주민등록", "계좌번호", "계좌", "비밀번호", "인증번호", "카드번호", "보안카드",
            "공동인증서", "otp", "개인정보", "신분증"
    );
    private static final Set<String> SHORTENER_DOMAINS = new LinkedHashSet<>(Arrays.asList(
            "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly", "cutt.ly",
            "han.gl", "me2.kr", "vo.la", "url.kr", "reurl.kr", "lrl.kr"
    ));
    private static final List<String> OFFICIAL_DOMAINS = Arrays.asList(
            "gov.kr", "go.kr", "police.go.kr", "spo.go.kr", "nts.go.kr", "customs.go.kr",
            "fss.or.kr", "kisa.or.kr", "boho.or.kr", "epost.go.kr", "nhis.or.kr", "kbstar.com",
            "shinhan.com", "nonghyup.com", "kakaobank.com", "kakao.com", "naver.com", "coupang.com",
            "cjlogistics.com"
    );
    private static final List<String> BRAND_LIKE_HOST_TERMS = Arrays.asList(
            "gov", "police", "spo", "nts", "tax", "customs", "bank", "kb", "shinhan", "nh",
            "kakao", "naver", "coupang", "cj", "epost"
    );

    private FeatureExtractor() {
    }

    static TextFeatures extract(String text) {
        TextFeatures features = new TextFeatures();
        features.messageHash = sha256(text);

        List<String> urls = extractUrls(text);
        List<String> orgHits = findHits(text, ORG_KEYWORDS);
        List<String> urgentHits = findHits(text, URGENCY_KEYWORDS);
        List<String> actionHits = findHits(text, ACTION_KEYWORDS);
        List<String> appHits = findHits(text, APP_INSTALL_KEYWORDS);
        List<String> piiHits = findHits(text, PII_KEYWORDS);

        boolean hasNonHttps = false;
        boolean hasShortUrl = false;
        boolean hasSuspiciousUrl = false;
        Set<String> hosts = new LinkedHashSet<>();

        for (String url : urls) {
            UrlParts parts = parseUrl(url);
            String host = parts.host;
            if (!host.isEmpty()) hosts.add(host);
            String compact = host.replaceFirst("^www\\.", "");
            String path = parts.path == null ? "" : parts.path;

            boolean nonHttps = !"https".equals(parts.scheme);
            boolean shortener = SHORTENER_DOMAINS.contains(compact);
            boolean suspicious = isIpHost(compact)
                    || compact.contains("xn--")
                    || countSymbols(url) >= 5
                    || url.length() >= 75
                    || (entropy(path) >= 4.0 && path.length() >= 16)
                    || looksBrandImpersonating(compact);

            hasNonHttps |= nonHttps;
            hasShortUrl |= shortener;
            hasSuspiciousUrl |= suspicious;
        }

        features.urlCount = urls.size();
        putFlag(features, "has_url", !urls.isEmpty());
        putFlag(features, "has_non_https_url", hasNonHttps);
        putFlag(features, "has_short_url", hasShortUrl);
        putFlag(features, "has_suspicious_url_shape", hasSuspiciousUrl);
        putFlag(features, "has_org_keyword", !orgHits.isEmpty());
        putFlag(features, "has_urgency", !urgentHits.isEmpty());
        putFlag(features, "has_action_request", !actionHits.isEmpty());
        putFlag(features, "has_app_install_request", !appHits.isEmpty());
        putFlag(features, "has_pii_request", !piiHits.isEmpty());
        putFlag(features, "has_money", AMOUNT_PATTERN.matcher(text).find());
        putFlag(features, "has_phone", PHONE_PATTERN.matcher(text).find());

        if (!urls.isEmpty()) {
            features.reasons.add(hosts.isEmpty() ? "URL 포함" : "URL 포함(" + joinFirst(hosts, 3) + ")");
        }
        if (hasNonHttps) features.reasons.add("HTTPS가 아닌 URL 또는 스킴 없는 URL");
        if (hasShortUrl) features.reasons.add("단축 URL 사용");
        if (hasSuspiciousUrl) features.reasons.add("URL 형태 이상 징후");
        if (!orgHits.isEmpty()) features.reasons.add("기관/브랜드 사칭 가능 키워드: " + joinFirst(orgHits, 4));
        if (!urgentHits.isEmpty()) features.reasons.add("긴급성 표현: " + joinFirst(urgentHits, 4));
        if (!actionHits.isEmpty()) features.reasons.add("클릭/인증/설치 등 행동 유도: " + joinFirst(actionHits, 4));
        if (!appHits.isEmpty()) features.reasons.add("앱 설치 유도 표현");
        if (!piiHits.isEmpty()) features.reasons.add("개인정보/인증정보 요구 표현");
        if (features.flags.get("has_money")) features.reasons.add("금액/결제 표현");

        return features;
    }

    private static void putFlag(TextFeatures features, String name, boolean active) {
        features.flags.put(name, active);
        if (active) {
            features.modelTokens.add("__" + name + "__");
        }
    }

    static List<String> extractUrls(String text) {
        List<String> urls = new ArrayList<>();
        Matcher matcher = URL_PATTERN.matcher(text);
        while (matcher.find()) {
            String url = matcher.group().replaceAll("[.,;:!?)\\]\\}>'\"]+$", "");
            if (!url.isEmpty()) urls.add(url);
        }
        return urls;
    }

    static double heuristicScore(TextFeatures features) {
        double score = 0.0;
        score += weight(features, "has_url", 0.14);
        score += weight(features, "has_non_https_url", 0.10);
        score += weight(features, "has_short_url", 0.12);
        score += weight(features, "has_suspicious_url_shape", 0.13);
        score += weight(features, "has_org_keyword", 0.10);
        score += weight(features, "has_urgency", 0.12);
        score += weight(features, "has_action_request", 0.12);
        score += weight(features, "has_app_install_request", 0.15);
        score += weight(features, "has_pii_request", 0.14);
        score += weight(features, "has_money", 0.08);

        if (isActive(features, "has_url") && (isActive(features, "has_urgency") || isActive(features, "has_action_request"))) {
            score += 0.08;
        }
        if (isActive(features, "has_org_keyword") && isActive(features, "has_pii_request")) {
            score += 0.07;
        }
        if (features.urlCount >= 2) {
            score += 0.04;
        }
        return round4(Math.min(score, 1.0));
    }

    private static double weight(TextFeatures features, String key, double value) {
        return isActive(features, key) ? value : 0.0;
    }

    private static boolean isActive(TextFeatures features, String key) {
        Boolean value = features.flags.get(key);
        return value != null && value;
    }

    private static List<String> findHits(String text, List<String> keywords) {
        String lowered = text.toLowerCase(Locale.ROOT);
        List<String> hits = new ArrayList<>();
        for (String keyword : keywords) {
            if (lowered.contains(keyword.toLowerCase(Locale.ROOT))) {
                hits.add(keyword);
            }
        }
        return hits;
    }

    private static UrlParts parseUrl(String rawUrl) {
        String url = rawUrl.matches("(?i)^https?://.*") ? rawUrl : "http://" + rawUrl;
        try {
            URI uri = new URI(url);
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
            String path = uri.getRawPath() == null ? "" : uri.getRawPath();
            return new UrlParts(host, scheme, path);
        } catch (Exception ignored) {
            return new UrlParts("", "", "");
        }
    }

    private static boolean isIpHost(String host) {
        return host.matches("(?:\\d{1,3}\\.){3}\\d{1,3}(?::\\d+)?");
    }

    private static boolean looksBrandImpersonating(String host) {
        if (host.isEmpty()) return false;
        for (String official : OFFICIAL_DOMAINS) {
            if (host.equals(official) || host.endsWith("." + official)) {
                return false;
            }
        }
        for (String term : BRAND_LIKE_HOST_TERMS) {
            if (host.contains(term)) {
                return true;
            }
        }
        return false;
    }

    private static int countSymbols(String text) {
        int count = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '-' || c == '_' || c == '%' || c == '?' || c == '=' || c == '&') count++;
        }
        return count;
    }

    private static double entropy(String value) {
        if (value == null || value.isEmpty()) return 0.0;
        int[] counts = new int[256];
        int total = 0;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c < 256) {
                counts[c]++;
                total++;
            }
        }
        if (total == 0) return 0.0;
        double entropy = 0.0;
        for (int count : counts) {
            if (count > 0) {
                double p = count / (double) total;
                entropy -= p * (Math.log(p) / Math.log(2));
            }
        }
        return entropy;
    }

    static String sha256(String text) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashed = digest.digest(text.getBytes(StandardCharsets.UTF_8));
            StringBuilder builder = new StringBuilder();
            for (byte b : hashed) builder.append(String.format(Locale.ROOT, "%02x", b));
            return builder.toString();
        } catch (Exception e) {
            return "";
        }
    }

    static double round4(double value) {
        return Math.round(value * 10000.0) / 10000.0;
    }

    private static String joinFirst(Iterable<String> values, int max) {
        StringBuilder builder = new StringBuilder();
        int count = 0;
        for (String value : values) {
            if (count > 0) builder.append(", ");
            builder.append(value);
            count++;
            if (count >= max) break;
        }
        return builder.toString();
    }

    private static final class UrlParts {
        final String host;
        final String scheme;
        final String path;

        UrlParts(String host, String scheme, String path) {
            this.host = host;
            this.scheme = scheme;
            this.path = path;
        }
    }
}
