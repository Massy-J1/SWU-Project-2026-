package kr.ac.swu.smishingguard;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;

public class SmsReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) {
            return;
        }

        SmsMessage[] messages = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        if (messages == null || messages.length == 0) {
            return;
        }

        StringBuilder body = new StringBuilder();
        for (SmsMessage message : messages) {
            if (message != null && message.getMessageBody() != null) {
                body.append(message.getMessageBody());
            }
        }

        String text = body.toString().trim();
        if (text.isEmpty()) {
            return;
        }

        try {
            TfidfDetector detector = TfidfDetector.fromAssets(context);
            DetectionResult result = detector.analyze(text);
            if (result.isRisky()) {
                SmsAlertNotifier.notifyRisk(context, result);
            }
        } catch (Exception ignored) {
            // Keep SMS delivery unaffected if the detector fails.
        }
    }
}
