package kr.ac.swu.smishingguard;

import android.content.Context;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class TfidfDetector {
    private static final Pattern TOKEN_PATTERN = Pattern.compile("[가-힣A-Za-z0-9_]+");
    private static final Pattern HANGUL_PATTERN = Pattern.compile("[가-힣]");

    private final Map<String, Double> idf;
    private final Map<String, Map<String, Double>> centroids;
    private final Map<String, Integer> classCounts;
    private final double threshold;

    private TfidfDetector(
            Map<String, Double> idf,
            Map<String, Map<String, Double>> centroids,
            Map<String, Integer> classCounts,
            double threshold
    ) {
        this.idf = idf;
        this.centroids = centroids;
        this.classCounts = classCounts;
        this.threshold = threshold;
    }

    public static TfidfDetector fromAssets(Context context) throws Exception {
        String json = readAsset(context, "smishing_tfidf_model.json");
        JSONObject root = new JSONObject(json);
        return new TfidfDetector(
                toDoubleMap(root.getJSONObject("idf")),
                toNestedDoubleMap(root.getJSONObject("centroids")),
                toIntMap(root.getJSONObject("class_counts")),
                root.optDouble("threshold", 0.55)
        );
    }

    public DetectionResult analyze(String text) {
        TextFeatures features = FeatureExtractor.extract(text);
        Map<String, Double> vector = vectorize(tokenize(text, features));
        int totalDocs = 0;
        for (int count : classCounts.values()) totalDocs += count;
        if (totalDocs == 0) totalDocs = 1;

        Map<String, Double> scores = new LinkedHashMap<>();
        for (Map.Entry<String, Map<String, Double>> entry : centroids.entrySet()) {
            String label = entry.getKey();
            Map<String, Double> centroid = entry.getValue();
            double dot = 0.0;
            for (Map.Entry<String, Double> token : vector.entrySet()) {
                Double centroidValue = centroid.get(token.getKey());
                if (centroidValue != null) {
                    dot += token.getValue() * centroidValue;
                }
            }
            int classCount = classCounts.containsKey(label) ? classCounts.get(label) : 0;
            double prior = Math.log((classCount + 1.0) / (totalDocs + centroids.size()));
            scores.put(label, dot + 0.03 * prior);
        }

        double modelProbability = softmaxProbability(scores, "smishing");
        double ruleProbability = FeatureExtractor.heuristicScore(features);
        double risk = FeatureExtractor.round4(0.70 * modelProbability + 0.30 * ruleProbability);
        if (ruleProbability >= 0.75) risk = Math.max(risk, 0.72);
        if (ruleProbability >= 0.90) risk = Math.max(risk, 0.82);
        risk = FeatureExtractor.round4(risk);

        String label = risk >= threshold ? "smishing" : "ham";
        return new DetectionResult(
                label,
                risk,
                FeatureExtractor.round4(modelProbability),
                ruleProbability,
                threshold,
                features.messageHash,
                features.reasons,
                features.flags,
                features.urlCount
        );
    }

    private List<String> tokenize(String text, TextFeatures features) {
        String normalized = FeatureExtractor.URL_PATTERN.matcher(text.toLowerCase(Locale.ROOT)).replaceAll(" URLTOKEN ");
        normalized = normalized.replaceAll("\\d+", " NUMTOKEN ");

        List<String> tokens = new ArrayList<>();
        Matcher matcher = TOKEN_PATTERN.matcher(normalized);
        while (matcher.find()) {
            String part = matcher.group();
            if (part.length() >= 2) {
                tokens.add(part);
            }

            String hangul = onlyHangul(part);
            if (hangul.length() >= 2) {
                for (int n = 2; n <= 3; n++) {
                    for (int i = 0; i <= hangul.length() - n; i++) {
                        tokens.add("char" + n + ":" + hangul.substring(i, i + n));
                    }
                }
            }
        }
        tokens.addAll(features.modelTokens);
        return tokens;
    }

    private String onlyHangul(String value) {
        Matcher matcher = HANGUL_PATTERN.matcher(value);
        StringBuilder builder = new StringBuilder();
        while (matcher.find()) builder.append(matcher.group());
        return builder.toString();
    }

    private Map<String, Double> vectorize(List<String> tokens) {
        Map<String, Integer> counts = new HashMap<>();
        int total = 0;
        for (String token : tokens) {
            if (idf.containsKey(token)) {
                counts.put(token, counts.containsKey(token) ? counts.get(token) + 1 : 1);
                total++;
            }
        }
        if (total == 0) total = 1;

        Map<String, Double> vector = new HashMap<>();
        for (Map.Entry<String, Integer> entry : counts.entrySet()) {
            vector.put(entry.getKey(), (entry.getValue() / (double) total) * idf.get(entry.getKey()));
        }
        return l2Normalize(vector);
    }

    private static Map<String, Double> l2Normalize(Map<String, Double> vector) {
        double norm = 0.0;
        for (double value : vector.values()) norm += value * value;
        norm = Math.sqrt(norm);
        if (norm == 0.0) return vector;
        Map<String, Double> normalized = new HashMap<>();
        for (Map.Entry<String, Double> entry : vector.entrySet()) {
            normalized.put(entry.getKey(), entry.getValue() / norm);
        }
        return normalized;
    }

    private static double softmaxProbability(Map<String, Double> scores, String label) {
        if (scores.isEmpty()) return 0.0;
        double max = Double.NEGATIVE_INFINITY;
        for (double value : scores.values()) max = Math.max(max, value);

        double total = 0.0;
        double target = 0.0;
        for (Map.Entry<String, Double> entry : scores.entrySet()) {
            double exp = Math.exp((entry.getValue() - max) * 10.0);
            total += exp;
            if (label.equals(entry.getKey())) target = exp;
        }
        return total == 0.0 ? 0.0 : target / total;
    }

    private static String readAsset(Context context, String name) throws Exception {
        try (InputStream input = context.getAssets().open(name);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int read;
            while ((read = input.read(buffer)) != -1) {
                output.write(buffer, 0, read);
            }
            return output.toString(StandardCharsets.UTF_8.name());
        }
    }

    private static Map<String, Double> toDoubleMap(JSONObject object) throws Exception {
        Map<String, Double> map = new HashMap<>();
        Iterator<String> keys = object.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            map.put(key, object.getDouble(key));
        }
        return map;
    }

    private static Map<String, Integer> toIntMap(JSONObject object) throws Exception {
        Map<String, Integer> map = new HashMap<>();
        Iterator<String> keys = object.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            map.put(key, object.getInt(key));
        }
        return map;
    }

    private static Map<String, Map<String, Double>> toNestedDoubleMap(JSONObject object) throws Exception {
        Map<String, Map<String, Double>> map = new LinkedHashMap<>();
        Iterator<String> keys = object.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            map.put(key, toDoubleMap(object.getJSONObject(key)));
        }
        return map;
    }
}
