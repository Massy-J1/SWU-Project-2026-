package kr.ac.swu.smishingguard;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

final class MmsReader {
    private static final Uri MMS_INBOX_URI = Uri.parse("content://mms/inbox");
    private static final Uri MMS_PART_URI = Uri.parse("content://mms/part");

    private MmsReader() {
    }

    static String readLatestText(Context context) {
        String mmsId = latestRecentMmsId(context);
        if (mmsId == null || mmsId.isEmpty()) {
            return "";
        }
        return readTextParts(context, mmsId).trim();
    }

    private static String latestRecentMmsId(Context context) {
        long nowSeconds = System.currentTimeMillis() / 1000L;
        String[] projection = {"_id", "date"};
        String selection = "date>=?";
        String[] selectionArgs = {String.valueOf(nowSeconds - 10 * 60)};

        try (Cursor cursor = context.getContentResolver().query(
                MMS_INBOX_URI,
                projection,
                selection,
                selectionArgs,
                "date DESC"
        )) {
            if (cursor != null && cursor.moveToFirst()) {
                return cursor.getString(cursor.getColumnIndexOrThrow("_id"));
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    private static String readTextParts(Context context, String mmsId) {
        StringBuilder builder = new StringBuilder();
        String[] projection = {"_id", "ct", "text", "_data"};

        try (Cursor cursor = context.getContentResolver().query(
                MMS_PART_URI,
                projection,
                "mid=?",
                new String[]{mmsId},
                null
        )) {
            if (cursor == null) return "";
            while (cursor.moveToNext()) {
                String contentType = getString(cursor, "ct");
                if (!"text/plain".equalsIgnoreCase(contentType)) {
                    continue;
                }

                String text = getString(cursor, "text");
                if (text != null && !text.trim().isEmpty()) {
                    builder.append(text).append('\n');
                    continue;
                }

                String partId = getString(cursor, "_id");
                String data = getString(cursor, "_data");
                if (partId != null && data != null && !data.isEmpty()) {
                    String streamText = readPartStream(context, partId);
                    if (!streamText.trim().isEmpty()) {
                        builder.append(streamText).append('\n');
                    }
                }
            }
        } catch (Exception ignored) {
        }

        return builder.toString();
    }

    private static String readPartStream(Context context, String partId) {
        Uri uri = Uri.parse("content://mms/part/" + partId);
        try (InputStream input = context.getContentResolver().openInputStream(uri);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            if (input == null) return "";
            byte[] buffer = new byte[1024];
            int read;
            while ((read = input.read(buffer)) != -1) {
                output.write(buffer, 0, read);
            }
            return output.toString(StandardCharsets.UTF_8.name());
        } catch (Exception ignored) {
            return "";
        }
    }

    private static String getString(Cursor cursor, String column) {
        int index = cursor.getColumnIndex(column);
        if (index < 0 || cursor.isNull(index)) {
            return "";
        }
        return cursor.getString(index);
    }
}
