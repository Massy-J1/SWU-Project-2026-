# Smishing Guard Android App

폰에서 직접 실행하는 오프라인 스미싱 탐지 앱입니다. 서버 없이 APK 안의 `assets/smishing_tfidf_model.json` 모델을 읽어 문자 위험도를 계산합니다.

## 기능

- 문자 내용 붙여넣기
- 위험/정상 판정
- 위험점수와 판단 근거 표시
- 결과 복사
- 새 SMS 자동 감지
- 새 MMS/LMS 텍스트 자동 감지
- 위험 문자 수신 시 상단 알림 경고
- 원문을 외부 서버로 전송하지 않음

## Android Studio로 APK 만들기

이미 생성된 APK:

```text
mobile\smishing_guard_android\app\build\outputs\apk\debug\app-debug.apk
```

다시 만들려면:

1. Android Studio 실행
2. `Open` 선택
3. 아래 폴더 열기

```text
C:\Users\ogh00\Desktop\work\SWU_project\mobile\smishing_guard_android
```

4. Gradle Sync가 끝날 때까지 기다리기
5. 상단 메뉴에서 `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`
6. APK 위치

```text
mobile\smishing_guard_android\app\build\outputs\apk\debug\app-debug.apk
```

## 폰에 설치하기

방법 A: USB 연결

1. 폰에서 개발자 옵션과 USB 디버깅 켜기
2. Android Studio의 `Device Manager` 또는 `Run app`으로 설치

방법 B: APK 파일 직접 옮기기

1. `app-debug.apk`를 카카오톡, 메일, USB 등으로 폰에 옮기기
2. 폰에서 APK 열기
3. `알 수 없는 앱 설치 허용`이 뜨면 허용
4. 설치 후 `Smishing Guard` 실행

## 테스트 방법

앱에서 `위험 예시` 버튼을 누르고 `분석하기`를 누릅니다.

예상 결과:

```text
위험: 스미싱 의심
URL 포함
긴급성 표현
행동 유도
기관/브랜드 사칭 가능 키워드
```

정상 예시는 `정상 가능성 높음`으로 나와야 합니다.

## 자동 문자 감지 사용 방법

1. 앱 실행
2. `자동 감지 권한 켜기` 누르기
3. 권한 창에서 SMS/MMS 수신 권한과 문자 읽기 권한 허용
4. Android 13 이상이면 알림 권한도 허용
5. 다른 폰에서 테스트 문자 보내기

테스트 문자 예시:

```text
[정부24] 피해 지원금 신청 대상. 오늘 마감 http://gov24-benefit.example
```

예상 결과:

```text
스미싱 의심 문자 감지
위험점수 ... · URL 포함(...)
```

폰 상단 알림을 누르면 앱이 열립니다.

## 현재 범위

현재 앱은 새로 수신되는 SMS와 텍스트 MMS/LMS를 자동 분석합니다. 기존 문자함 전체를 읽지는 않습니다. 지금 버전은 연구/테스트용 직접 설치 APK로 사용하세요.
