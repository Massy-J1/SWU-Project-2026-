"""Tiny TF-IDF centroid classifier for the first smishing baseline."""

from __future__ import annotations

import json
import math
import random
import re
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

from .features import URL_RE, extract_features, heuristic_score

TOKEN_RE = re.compile(r"[가-힣A-Za-z0-9_]+")


def normalize_label(label: str) -> str:
    lowered = label.strip().lower()
    if lowered in {"spam", "smishing", "phishing", "malicious", "1", "true"}:
        return "smishing"
    if lowered in {"ham", "normal", "benign", "safe", "0", "false"}:
        return "ham"
    raise ValueError(f"unknown label: {label!r}")


def tokenize(text: str) -> list[str]:
    """Tokenize Korean/English SMS text and append explainable feature tokens."""

    normalized = URL_RE.sub(" URLTOKEN ", text.lower())
    normalized = re.sub(r"\d+", " NUMTOKEN ", normalized)
    parts = TOKEN_RE.findall(normalized)

    tokens: list[str] = []
    for part in parts:
        if len(part) >= 2:
            tokens.append(part)

        hangul = "".join(re.findall(r"[가-힣]", part))
        if len(hangul) >= 2:
            for n in (2, 3):
                for i in range(0, len(hangul) - n + 1):
                    tokens.append(f"char{n}:{hangul[i:i+n]}")

    tokens.extend(extract_features(text)["model_tokens"])
    return tokens


def _l2_normalize(vector: dict[str, float]) -> dict[str, float]:
    norm = math.sqrt(sum(value * value for value in vector.values()))
    if norm == 0:
        return vector
    return {key: value / norm for key, value in vector.items()}


def _softmax(scores: dict[str, float], scale: float = 10.0) -> dict[str, float]:
    if not scores:
        return {}
    max_score = max(scores.values())
    exp_scores = {label: math.exp((score - max_score) * scale) for label, score in scores.items()}
    total = sum(exp_scores.values()) or 1.0
    return {label: value / total for label, value in exp_scores.items()}


class TfidfCentroidModel:
    """A dependency-free text classifier suitable for a quick classroom MVP."""

    def __init__(
        self,
        *,
        idf: dict[str, float],
        centroids: dict[str, dict[str, float]],
        class_counts: dict[str, int],
        threshold: float = 0.55,
        metadata: dict | None = None,
    ) -> None:
        self.idf = idf
        self.centroids = centroids
        self.class_counts = class_counts
        self.threshold = threshold
        self.metadata = metadata or {}

    @classmethod
    def train(
        cls,
        records: Iterable[tuple[str, str]],
        *,
        min_df: int = 1,
        threshold: float = 0.55,
    ) -> "TfidfCentroidModel":
        docs: list[tuple[str, list[str]]] = []
        doc_freq: Counter[str] = Counter()
        class_counts: Counter[str] = Counter()

        for text, raw_label in records:
            label = normalize_label(raw_label)
            tokens = tokenize(text)
            if not tokens:
                continue
            docs.append((label, tokens))
            doc_freq.update(set(tokens))
            class_counts[label] += 1

        if len(class_counts) < 2:
            raise ValueError("training needs at least two labels")

        vocab = {token for token, df in doc_freq.items() if df >= min_df}
        n_docs = len(docs)
        idf = {
            token: math.log((1 + n_docs) / (1 + doc_freq[token])) + 1.0
            for token in sorted(vocab)
        }

        summed: dict[str, Counter[str]] = defaultdict(Counter)
        for label, tokens in docs:
            vector = cls._vectorize_tokens(tokens, idf)
            for token, value in vector.items():
                summed[label][token] += value

        centroids: dict[str, dict[str, float]] = {}
        for label, vector_sum in summed.items():
            count = class_counts[label]
            averaged = {token: value / count for token, value in vector_sum.items()}
            centroids[label] = _l2_normalize(averaged)

        metadata = {
            "model_type": "tfidf_centroid_v1",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "n_training_docs": n_docs,
            "labels": sorted(class_counts),
            "min_df": min_df,
            "note": "Offline baseline model. It does not open SMS links.",
        }

        return cls(
            idf=idf,
            centroids=centroids,
            class_counts=dict(class_counts),
            threshold=threshold,
            metadata=metadata,
        )

    @staticmethod
    def _vectorize_tokens(tokens: list[str], idf: dict[str, float]) -> dict[str, float]:
        counts = Counter(token for token in tokens if token in idf)
        total = sum(counts.values()) or 1
        vector = {
            token: (count / total) * idf[token]
            for token, count in counts.items()
        }
        return _l2_normalize(vector)

    def vectorize(self, text: str) -> dict[str, float]:
        return self._vectorize_tokens(tokenize(text), self.idf)

    def predict(self, text: str) -> dict:
        features = extract_features(text)
        vector = self.vectorize(text)
        total_docs = sum(self.class_counts.values()) or 1

        scores = {}
        for label, centroid in self.centroids.items():
            dot = sum(value * centroid.get(token, 0.0) for token, value in vector.items())
            prior = math.log((self.class_counts.get(label, 0) + 1) / (total_docs + len(self.centroids)))
            scores[label] = dot + 0.03 * prior

        probabilities = _softmax(scores)
        model_probability = probabilities.get("smishing", 0.0)
        rules_probability = heuristic_score(features)
        risk_score = round((0.70 * model_probability) + (0.30 * rules_probability), 4)

        if rules_probability >= 0.75:
            risk_score = max(risk_score, 0.72)
        if rules_probability >= 0.90:
            risk_score = max(risk_score, 0.82)

        label = "smishing" if risk_score >= self.threshold else "ham"
        return {
            "label": label,
            "risk_score": risk_score,
            "model_probability": round(model_probability, 4),
            "heuristic_score": rules_probability,
            "threshold": self.threshold,
            "features": features,
        }

    def save(self, path: str | Path) -> None:
        payload = {
            "idf": self.idf,
            "centroids": self.centroids,
            "class_counts": self.class_counts,
            "threshold": self.threshold,
            "metadata": self.metadata,
        }
        Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "TfidfCentroidModel":
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls(
            idf=payload["idf"],
            centroids=payload["centroids"],
            class_counts=payload["class_counts"],
            threshold=payload.get("threshold", 0.55),
            metadata=payload.get("metadata", {}),
        )


def stratified_split(
    records: list[tuple[str, str]],
    *,
    test_size: float = 0.30,
    seed: int = 42,
) -> tuple[list[tuple[str, str]], list[tuple[str, str]]]:
    rng = random.Random(seed)
    groups: dict[str, list[tuple[str, str]]] = defaultdict(list)
    for text, label in records:
        groups[normalize_label(label)].append((text, normalize_label(label)))

    train: list[tuple[str, str]] = []
    test: list[tuple[str, str]] = []
    for label, group in groups.items():
        rng.shuffle(group)
        if len(group) <= 1:
            train.extend(group)
            continue
        n_test = max(1, round(len(group) * test_size))
        n_test = min(n_test, len(group) - 1)
        test.extend(group[:n_test])
        train.extend(group[n_test:])

    rng.shuffle(train)
    rng.shuffle(test)
    return train, test


def evaluate(model: TfidfCentroidModel, records: list[tuple[str, str]]) -> dict:
    counts = {
        "tp": 0,
        "tn": 0,
        "fp": 0,
        "fn": 0,
    }
    examples = []

    for text, raw_label in records:
        truth = normalize_label(raw_label)
        pred = model.predict(text)
        label = pred["label"]
        if truth == "smishing" and label == "smishing":
            counts["tp"] += 1
        elif truth == "ham" and label == "ham":
            counts["tn"] += 1
        elif truth == "ham" and label == "smishing":
            counts["fp"] += 1
        elif truth == "smishing" and label == "ham":
            counts["fn"] += 1

        if truth != label:
            examples.append(
                {
                    "truth": truth,
                    "predicted": label,
                    "risk_score": pred["risk_score"],
                    "sha256": pred["features"]["message_sha256"],
                    "reasons": pred["features"]["reasons"],
                }
            )

    tp, tn, fp, fn = counts["tp"], counts["tn"], counts["fp"], counts["fn"]
    total = tp + tn + fp + fn
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    accuracy = (tp + tn) / total if total else 0.0

    return {
        "accuracy": round(accuracy, 4),
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4),
        "confusion_matrix": {
            "actual_smishing_pred_smishing": tp,
            "actual_smishing_pred_ham": fn,
            "actual_ham_pred_smishing": fp,
            "actual_ham_pred_ham": tn,
        },
        "n_eval": total,
        "errors": examples[:10],
    }
