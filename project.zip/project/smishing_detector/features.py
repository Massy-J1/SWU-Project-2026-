"""Regex and URL features for the first smishing MVP.

The feature extractor is intentionally offline: it never opens or follows URLs.
That keeps the first classroom prototype safe and reproducible.
"""

from __future__ import annotations

import hashlib
import math
import re
from urllib.parse import urlparse

URL_RE = re.compile(
    r"""(?ix)
    \b(?:https?://|www\.)[^\s<>"']+
    |
    \b(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+
      (?:[a-z]{2,})(?:/[^\s<>"']*)?
    """
)

PHONE_RE = re.compile(r"(?<!\d)(?:0\d{1,2}[-.\s]?\d{3,4}[-.\s]?\d{4}|1[0-9]{2,3}[-.\s]?\d{4})(?!\d)")
AMOUNT_RE = re.compile(r"(?:\d{1,3}(?:,\d{3})+|\d+)\s*(?:원|만원|억원|달러|USD|KRW)|[₩$]\s*\d+")

ORG_KEYWORDS = [
    "정부24",
    "정부",
    "경찰청",
    "검찰",
    "법원",
    "국세청",
    "관세청",
    "금융감독원",
    "금감원",
    "건강보험",
    "공단",
    "우체국",
    "택배",
    "cj대한통운",
    "쿠팡",
    "국민은행",
    "신한은행",
    "농협",
    "카카오",
    "네이버",
    "통신사",
    "카드사",
]

URGENCY_KEYWORDS = [
    "긴급",
    "즉시",
    "오늘",
    "당일",
    "마감",
    "기한",
    "최종",
    "정지",
    "차단",
    "압류",
    "연체",
    "미납",
    "경고",
    "확인필",
    "보류",
    "제한",
]

ACTION_KEYWORDS = [
    "클릭",
    "접속",
    "확인",
    "입력",
    "인증",
    "다운로드",
    "설치",
    "열람",
    "조회",
    "신청",
    "업데이트",
    "재등록",
    "납부",
    "환급",
    "결제",
    "취소",
]

APP_INSTALL_KEYWORDS = [
    "apk",
    "앱설치",
    "앱 설치",
    "설치파일",
    "보안앱",
    "원격제어",
    "원격 제어",
    "업데이트 설치",
]

PII_KEYWORDS = [
    "주민번호",
    "주민등록",
    "계좌번호",
    "계좌",
    "비밀번호",
    "인증번호",
    "카드번호",
    "보안카드",
    "공동인증서",
    "otp",
    "개인정보",
    "신분증",
]

SHORTENER_DOMAINS = {
    "bit.ly",
    "tinyurl.com",
    "t.co",
    "goo.gl",
    "ow.ly",
    "is.gd",
    "buff.ly",
    "cutt.ly",
    "han.gl",
    "me2.kr",
    "vo.la",
    "url.kr",
    "reurl.kr",
    "lrl.kr",
}

OFFICIAL_DOMAINS = (
    "gov.kr",
    "go.kr",
    "police.go.kr",
    "spo.go.kr",
    "nts.go.kr",
    "customs.go.kr",
    "fss.or.kr",
    "kisa.or.kr",
    "boho.or.kr",
    "epost.go.kr",
    "nhis.or.kr",
    "kbstar.com",
    "shinhan.com",
    "nonghyup.com",
    "kakaobank.com",
    "kakao.com",
    "naver.com",
    "coupang.com",
    "cjlogistics.com",
)

BRAND_LIKE_HOST_TERMS = (
    "gov",
    "police",
    "spo",
    "nts",
    "tax",
    "customs",
    "bank",
    "kb",
    "shinhan",
    "nh",
    "kakao",
    "naver",
    "coupang",
    "cj",
    "epost",
)


def message_hash(text: str) -> str:
    """Return a stable hash so logs can avoid storing the original message."""

    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def extract_urls(text: str) -> list[str]:
    urls = []
    for match in URL_RE.finditer(text):
        url = match.group(0).strip(".,;:!?) ]}>'\"")
        if url:
            urls.append(url)
    return urls


def _host_for_url(url: str) -> tuple[str, str]:
    original = url
    if not re.match(r"(?i)^https?://", url):
        url = "http://" + url
    parsed = urlparse(url)
    return parsed.netloc.lower(), parsed.scheme.lower() or ("https" if original.lower().startswith("https://") else "")


def _find_hits(text: str, keywords: list[str]) -> list[str]:
    lowered = text.lower()
    hits = []
    for keyword in keywords:
        if keyword.lower() in lowered:
            hits.append(keyword)
    return hits


def _is_ip_host(host: str) -> bool:
    return bool(re.fullmatch(r"(?:\d{1,3}\.){3}\d{1,3}(?::\d+)?", host))


def _looks_brand_impersonating(host: str) -> bool:
    if not host:
        return False
    if any(host == domain or host.endswith("." + domain) for domain in OFFICIAL_DOMAINS):
        return False
    return any(term in host for term in BRAND_LIKE_HOST_TERMS)


def _url_entropy(value: str) -> float:
    if not value:
        return 0.0
    counts = {}
    for char in value:
        counts[char] = counts.get(char, 0) + 1
    total = len(value)
    return -sum((count / total) * math.log2(count / total) for count in counts.values())


def extract_features(text: str) -> dict:
    """Extract explainable text and URL features from one SMS body."""

    urls = extract_urls(text)
    org_hits = _find_hits(text, ORG_KEYWORDS)
    urgent_hits = _find_hits(text, URGENCY_KEYWORDS)
    action_hits = _find_hits(text, ACTION_KEYWORDS)
    app_hits = _find_hits(text, APP_INSTALL_KEYWORDS)
    pii_hits = _find_hits(text, PII_KEYWORDS)
    amounts = AMOUNT_RE.findall(text)
    phones = PHONE_RE.findall(text)

    url_details = []
    for url in urls:
        host, scheme = _host_for_url(url)
        compact = re.sub(r"^www\.", "", host)
        pathish = urlparse(url if re.match(r"(?i)^https?://", url) else "http://" + url).path
        detail = {
            "host": host,
            "scheme": scheme,
            "length": len(url),
            "non_https": scheme != "https",
            "shortener": compact in SHORTENER_DOMAINS,
            "ip_host": _is_ip_host(compact),
            "punycode": "xn--" in compact,
            "many_symbols": sum(1 for c in url if c in "-_%?=&") >= 5,
            "long_url": len(url) >= 75,
            "high_entropy": _url_entropy(pathish) >= 4.0 and len(pathish) >= 16,
            "brand_impersonation_hint": _looks_brand_impersonating(compact),
        }
        url_details.append(detail)

    flags = {
        "has_url": bool(urls),
        "has_non_https_url": any(d["non_https"] for d in url_details),
        "has_short_url": any(d["shortener"] for d in url_details),
        "has_suspicious_url_shape": any(
            d["ip_host"]
            or d["punycode"]
            or d["many_symbols"]
            or d["long_url"]
            or d["high_entropy"]
            or d["brand_impersonation_hint"]
            for d in url_details
        ),
        "has_org_keyword": bool(org_hits),
        "has_urgency": bool(urgent_hits),
        "has_action_request": bool(action_hits),
        "has_app_install_request": bool(app_hits),
        "has_pii_request": bool(pii_hits),
        "has_money": bool(amounts),
        "has_phone": bool(phones),
    }

    reasons = []
    if flags["has_url"]:
        hosts = ", ".join(sorted({d["host"] for d in url_details if d["host"]})[:3])
        reasons.append(f"URL 포함({hosts})" if hosts else "URL 포함")
    if flags["has_non_https_url"]:
        reasons.append("HTTPS가 아닌 URL 또는 스킴 없는 URL")
    if flags["has_short_url"]:
        reasons.append("단축 URL 사용")
    if flags["has_suspicious_url_shape"]:
        reasons.append("URL 형태 이상 징후")
    if flags["has_org_keyword"]:
        reasons.append("기관/브랜드 사칭 가능 키워드: " + ", ".join(org_hits[:4]))
    if flags["has_urgency"]:
        reasons.append("긴급성 표현: " + ", ".join(urgent_hits[:4]))
    if flags["has_action_request"]:
        reasons.append("클릭/인증/설치 등 행동 유도: " + ", ".join(action_hits[:4]))
    if flags["has_app_install_request"]:
        reasons.append("앱 설치 유도 표현")
    if flags["has_pii_request"]:
        reasons.append("개인정보/인증정보 요구 표현")
    if flags["has_money"]:
        reasons.append("금액/결제 표현")

    model_tokens = []
    for name, active in flags.items():
        if active:
            model_tokens.append(f"__{name}__")

    return {
        "message_sha256": message_hash(text),
        "url_count": len(urls),
        "url_details": url_details,
        "keyword_hits": {
            "org": org_hits,
            "urgency": urgent_hits,
            "action": action_hits,
            "app_install": app_hits,
            "pii": pii_hits,
        },
        "amount_count": len(amounts),
        "phone_count": len(phones),
        "flags": flags,
        "reasons": reasons,
        "model_tokens": model_tokens,
    }


def heuristic_score(features: dict) -> float:
    """Return an explainable risk score in [0, 1] from handcrafted features."""

    flags = features["flags"]
    weights = {
        "has_url": 0.14,
        "has_non_https_url": 0.10,
        "has_short_url": 0.12,
        "has_suspicious_url_shape": 0.13,
        "has_org_keyword": 0.10,
        "has_urgency": 0.12,
        "has_action_request": 0.12,
        "has_app_install_request": 0.15,
        "has_pii_request": 0.14,
        "has_money": 0.08,
    }
    score = sum(weight for key, weight in weights.items() if flags.get(key))

    if flags["has_url"] and (flags["has_urgency"] or flags["has_action_request"]):
        score += 0.08
    if flags["has_org_keyword"] and flags["has_pii_request"]:
        score += 0.07
    if features["url_count"] >= 2:
        score += 0.04

    return round(min(score, 1.0), 4)
