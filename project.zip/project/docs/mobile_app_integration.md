# 모바일 앱 연동 메모

## Python으로 만들어도 되는가?

된다. 오늘 제출용 목표가 “처음 자료 테스트 모델”이면 Python이 가장 빠르고 안전하다. 모델 학습, 평가, 실험 로그, 결과 화면을 Python으로 만든 뒤 Android 앱에 옮기는 흐름이 일반적이다.

다만 실제로 휴대폰에 설치해서 문자 수신 시 자동 경고창을 띄우는 앱은 Python만으로 끝내기 어렵다. Android 앱 부분은 Kotlin/Java가 맞다.

## 권장 개발 단계

| 단계 | 구현 | 산출물 |
|---|---|---|
| 1단계 | Python 콘솔 모델 | 오늘 제출물 |
| 2단계 | Python JSON API 서버 | Android가 호출할 모델 서버 |
| 3단계 | Android 앱에서 문자 붙여넣기/공유받기 | 앱 화면 데모 |
| 4단계 | Android 내부 TF-IDF 엔진 이식 | 오프라인 앱 |
| 5단계 | `RECEIVE_SMS` 기반 자동 수신 감지 | 테스트용 자동 경고 앱 |

현재 저장소에는 1~5단계의 연구용 직접 설치 APK 구현이 들어 있다.

## 자동 SMS 감지 주의점

Android에서 SMS 수신을 자동 감지하려면 사용자가 앱에 SMS 수신 권한을 허용해야 한다. 지금 단계는 Play Store 배포가 아니라 연구용 직접 설치 APK이므로, 네 테스트 폰과 테스트 문자로 동작을 확인하는 데 집중한다.

나중에 공개 배포를 검토할 때 볼 공식 자료:

- Android Developers: `Permissions used only in default handlers`  
  `https://developer.android.com/guide/topics/permissions/default-handlers`
- Google Play Console Help: `Use of SMS or Call Log permission groups`  
  `https://support.google.com/googleplay/android-developer/answer/10208820`

## Android 앱 구조 초안

```text
Incoming SMS
  -> SmsReceiver 또는 기본 SMS 앱 수신부
  -> message body 추출
  -> SmsRiskClient.predict(message) 또는 온디바이스 Detector.analyze(message)
  -> risk_score >= threshold 이면 Notification 또는 AlertDialog
```

현재 Android 앱은 `SmsReceiver -> TfidfDetector -> Notification` 흐름으로 동작한다. Android는 백그라운드에서 임의로 화면을 강제로 띄우는 것을 제한하므로, 자동 경고는 상단 알림으로 제공한다.

## Kotlin 의사코드

```kotlin
data class DetectionResult(
    val label: String,
    val riskScore: Double,
    val reasons: List<String>
)

class SmsRiskEngine {
    fun analyze(message: String): DetectionResult {
        val hasUrl = Regex("""https?://|www\.""").containsMatchIn(message)
        val urgent = listOf("긴급", "즉시", "오늘", "마감", "정지").any { it in message }
        val action = listOf("클릭", "접속", "인증", "입력", "설치").any { it in message }
        val score = listOf(hasUrl, urgent, action).count { it } / 3.0
        val reasons = mutableListOf<String>()
        if (hasUrl) reasons += "URL 포함"
        if (urgent) reasons += "긴급성 표현"
        if (action) reasons += "행동 유도 표현"
        return DetectionResult(
            label = if (score >= 0.6) "smishing" else "ham",
            riskScore = score,
            reasons = reasons
        )
    }
}
```

이 Kotlin 코드는 최종 모델이 아니라 모바일 화면 데모용 최소 규칙 엔진이다. Python 모델에서 검증한 특징 스키마를 앱에 옮길 때 출발점으로 사용한다.
