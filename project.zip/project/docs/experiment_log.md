# 실험 로그

## 1. 목표

문자 1건을 입력하면 스미싱 여부와 판단 근거를 출력하는 첫 테스트 모델을 만든다.

## 2. 사용 자료

| 자료 | 사용 방법 |
|---|---|
| 수업 PPT/DOCX | MVP, 특징 스키마, 산출물 기준 확인 |
| Kaggle/UCI SMS Spam Collection | 영어 spam/ham 공개 데이터 확장 후보 |
| APICK 전체 상품 목록 | URL HTML 추출, 화면 캡처, WHOIS, URL 유사도 같은 확장 API 아이디어 참고 |
| Naver Android SMS 가져오기 글 | Android에서 SMS 목록을 읽는 구현 방향 참고 |
| Hugging Face `fineweb_urls` | URL 원문과 domain 컬럼을 가진 대규모 URL 분석 후보 자료로 참고 |
| DBpia KoBERT+URL 특징 논문 | 최종 연구 방향: KoBERT 768차원 + URL 특징 10차원 + MLP 참고 |
| KISA 보호나라 피싱 주의 권고 | 실제 경고 문구, 사칭/URL/악성앱/개인정보 탈취 특징 참고 |

## 3. 오늘 구현한 것

| 산출물 | 파일 |
|---|---|
| 특징 추출 함수 | `smishing_detector/features.py` |
| TF-IDF 베이스라인 모델 | `smishing_detector/tfidf_model.py` |
| 학습/평가 스크립트 | `train.py` |
| 예측/경고 출력 스크립트 | `predict.py` |
| 모바일 연동 API | `api_server.py`, `docs/api_contract.md` |
| Android 호출 샘플 | `mobile/android_kotlin_sample/SmsRiskClient.kt` |
| Android 오프라인 앱 | `mobile/smishing_guard_android/` |
| 한국어 seed 라벨셋 | `data/smishing_seed_ko.csv` |
| 특징 스키마 표 | `docs/feature_schema.md` |
| 결과 지표 | `reports/metrics.json` |
| 결과 화면 | `reports/result_screen_smishing.txt`, `reports/result_screen_ham.txt` |

## 4. 실험 방법

```bash
python3 train.py
python3 predict.py "[정부24] 피해 지원금 신청 대상. 오늘 마감 http://gov24-benefit.example"
python3 predict.py "[학교] 내일 연구활동은 오후 2시에 시작합니다."
python3 scripts/run_experiment.py
```

## 5. 성공한 점

주의: `reports/metrics.json`의 F1 1.0은 합성 seed 데이터에서 파이프라인이 정상 동작했음을 보여 주는 값이다. 실제 서비스 성능으로 주장하면 안 되며, 실제/허가 데이터로 재평가해야 한다.

| 항목 | 결과 |
|---|---|
| 문자 1건 예측 | 동작 |
| 판단 근거 출력 | URL, 긴급성, 행동 유도, 기관 사칭 등 출력 |
| 원문 보호 | 결과 로그에 SHA-256 해시 출력 |
| 평가 지표 | 정확도, 정밀도, 재현율, F1, 혼동행렬 저장 |
| 외부 의존성 | Python 표준라이브러리만 사용 |
| 모바일 연동 | `POST /predict` API와 Kotlin 호출 샘플 작성 |
| 자동 감지 앱 | `RECEIVE_SMS` 기반 새 문자 자동 분석과 알림 경고 구현 |

## 6. 실패/한계

| 항목 | 내용 | 다음 해결 |
|---|---|---|
| 데이터 크기 | 현재 한국어 데이터는 합성 seed 데이터라 실제 분포와 다름 | 실제 공개/허가 데이터 추가, 직접 라벨링 |
| KoBERT 미사용 | 3시간 MVP라 무거운 딥러닝 모델은 제외 | 다음 단계에서 KoBERT 임베딩 + URL 특징 결합 |
| URL 실제 악성 여부 | URL에 접속하거나 평판 API를 호출하지 않음 | 안전한 샌드박스/API로 확장 |
| 모바일 자동 감지 | 새 SMS 수신 자동 분석은 구현했지만 기존 문자함 전체 분석은 제외 | 테스트 폰에서 SMS 수신 실험 후 보정 |
| 배포 보안 | API 인증/HTTPS는 아직 미구현 | 서버형으로 바꿀 때 reverse proxy, HTTPS, 토큰 추가 |

## 7. 막힌점

| 막힌점 | 이유 | 처리 |
|---|---|---|
| Kaggle 직접 다운로드 | 로그인/API 토큰이 필요할 수 있음 | 같은 원본 계열인 UCI 공개 미러 다운로드 스크립트 제공 |
| SMS 자동 읽기 | Android에서 SMS 수신 권한 허용이 필요함 | 테스트 폰에서 권한 허용 후 실험 |
| 실제 문자 저장 | 개인정보 포함 가능성 | 원문 대신 SHA-256 해시 사용 |

## 8. 다음 세션 목표

1. 팀원이 직접 만든 한국어 정상/스미싱 예시를 100개 이상 라벨링한다.
2. 오탐/미탐 사례를 보고 키워드와 URL 특징을 보정한다.
3. Android 앱은 먼저 “문자 붙여넣기 → 경고” 화면으로 만들고, 그 다음 자동 SMS 감지 권한 문제를 해결한다.
