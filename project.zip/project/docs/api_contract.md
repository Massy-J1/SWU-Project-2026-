# API 계약

모바일 앱이 서버형 Python 모델을 호출할 때 쓰는 최소 계약이다.

## `GET /health`

서버와 모델이 살아 있는지 확인한다.

응답:

```json
{
  "status": "ok",
  "model_loaded": true,
  "service": "smishing-detector"
}
```

## `POST /predict`

요청:

```json
{
  "message": "[정부24] 피해 지원금 신청 대상. 오늘 마감 http://..."
}
```

응답:

```json
{
  "label": "smishing",
  "risk_score": 0.82,
  "threshold": 0.55,
  "message_sha256": "해시값",
  "reasons": ["URL 포함(...)", "긴급성 표현: 오늘, 마감"],
  "flags": {
    "has_url": true,
    "has_urgency": true
  },
  "url_count": 1
}
```

## 실행

```bash
python3 train.py
python3 api_server.py --host 0.0.0.0 --port 8000
```

테스트:

```bash
curl -s http://127.0.0.1:8000/health
curl -s -X POST http://127.0.0.1:8000/predict \
  -H 'Content-Type: application/json' \
  -d '{"message":"[택배] 주소 오류로 배송 보류. 즉시 http://delivery-check.example 확인"}'
```

## 보안 메모

- 서버 로그에 문자 원문을 남기지 않는다.
- HTTPS 뒤에 배치한다.
- 테스트 외부 공개 전에는 인증 토큰 또는 내부망 제한을 둔다.
- URL 분석은 현재 오프라인 형태 분석만 한다. 서버가 의심 URL에 직접 접속하지 않는다.
