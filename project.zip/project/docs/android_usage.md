# 폰 설치 및 자동 감지 실험 방법

앱 위치:

```text
C:\Users\ogh00\Desktop\work\SWU_project\mobile\smishing_guard_android
```

## 1. APK 만들기

이미 빌드된 APK:

```text
C:\Users\ogh00\Desktop\work\SWU_project\mobile\smishing_guard_android\app\build\outputs\apk\debug\app-debug.apk
```

다시 빌드하려면 아래 순서를 사용합니다.

1. Android Studio 실행
2. `Open` 클릭
3. 위 앱 폴더 열기
4. Gradle Sync가 끝날 때까지 기다리기
5. 메뉴에서 `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`
6. 생성된 APK 위치 확인

```text
mobile\smishing_guard_android\app\build\outputs\apk\debug\app-debug.apk
```

## 2. 폰에 설치하기

방법 A: USB 설치

1. 폰에서 개발자 옵션 켜기
2. `USB 디버깅` 켜기
3. USB로 PC 연결
4. Android Studio에서 `Run` 누르기

방법 B: APK 직접 설치

1. `app-debug.apk`를 폰으로 옮기기
2. 폰에서 APK 열기
3. `알 수 없는 앱 설치 허용`이 뜨면 허용
4. `Smishing Guard` 설치

## 3. 자동 감지 켜기

1. 앱 실행
2. `자동 감지 권한 켜기` 누르기
3. `SMS/MMS 수신 권한`과 `문자 읽기 권한` 허용
4. Android 13 이상이면 `알림 권한`도 허용
5. 화면에 `켜짐`이 보이면 준비 완료

## 4. 실험하기

다른 폰에서 테스트 폰으로 아래 문자를 보내기:

```text
[정부24] 피해 지원금 신청 대상. 오늘 마감 http://gov24-benefit.example
```

예상 결과:

```text
스미싱 의심 문자 감지
위험점수 ... · URL 포함(...)
```

상단 알림을 누르면 앱이 열립니다.

## 5. 수동 분석도 가능

앱에 문자 내용을 붙여넣고 `분석하기`를 누르면 즉시 판정됩니다.

## 6. 안 될 때 확인

| 증상 | 확인할 것 |
|---|---|
| 새 문자가 와도 알림이 안 뜸 | 앱에서 자동 감지 상태가 `켜짐`인지 확인 |
| MMS/LMS가 안 잡힘 | 폰 설정 → 앱 → Smishing Guard → 권한 → SMS/MMS/문자 읽기/알림 허용 |
| 권한 창을 실수로 거절함 | 폰 설정 → 앱 → Smishing Guard → 권한 → SMS/MMS/알림 허용 |
| 설치가 막힘 | 알 수 없는 앱 설치 허용 |
| “앱이 설치되지 않았습니다” | 폰 설정 → 앱 → Smishing Guard가 있으면 삭제, 파일관리자/카톡/드라이브의 알 수 없는 앱 설치 허용 |
| 정상 문자는 알림이 안 뜸 | 정상 동작. 위험 문자만 알림 |
| 기존 문자함은 분석 안 됨 | 현재 버전은 새로 수신되는 SMS만 자동 분석 |
