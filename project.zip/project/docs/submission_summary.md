# 제출 요약

## 제출 조건 체크

| 조건 | 제출 파일/상태 |
|---|---|
| GitHub 커밋 1건 이상 | 로컬 git 커밋 `Initial smishing detection MVP` 생성 |
| 연구노트 1건 | `docs/research_note_2026-06-27.md` |
| 결과 화면 또는 파일 1개 | `reports/result_screen_smishing.txt`, `reports/metrics.json`, Android APK |
| 다음 세션 목표 1줄 | 연구노트 6번 항목에 작성 |

## 핵심 산출물

| 산출물 | 경로 |
|---|---|
| README | `README.md` |
| Python 탐지 모델 | `smishing_detector/`, `train.py`, `predict.py` |
| Android 앱 소스 | `mobile/smishing_guard_android/` |
| 설치 APK | `mobile/smishing_guard_android/app/build/outputs/apk/debug/app-debug.apk` |
| 실험 로그 | `docs/experiment_log.md` |
| 연구노트 | `docs/research_note_2026-06-27.md` |
| 특징표 | `reports/feature_table.csv` |
| 모델 평가 | `reports/metrics.json` |
| 결과 화면 | `reports/result_screen_smishing.txt`, `reports/result_screen_ham.txt` |

## 다음 세션 목표

실제/허가된 한국어 정상·스미싱 문자 라벨셋을 100개 이상으로 늘리고, Android 자동 감지에서 오탐·미탐 사례를 수집해 특징 가중치와 모델을 개선한다.
