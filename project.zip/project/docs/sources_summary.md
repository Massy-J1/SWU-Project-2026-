# 참고 자료 요약

확인일: 2026-06-27

| 자료 | 확인한 내용 | 프로젝트 반영 |
|---|---|---|
| `research_session.pptx` | 5팀 목표는 “문자 1건 → 스미싱 여부 + 근거 특징”, 오늘 산출물은 베이스라인 모델과 평가 | MVP 범위 고정 |
| `영재원_오후_연구활동_학생용_안내문.docx` | 특징 스키마: 기관사칭, 긴급성, 금전요구, 행동유도, URL, 앱설치, 개인정보 | `docs/feature_schema.md`, `features.py` |
| `영재원_오후_연구활동_학생용_용어설명집.docx` | TF-IDF는 가벼운 베이스라인, KoBERT는 다음 단계 후보 | 표준 라이브러리 TF-IDF baseline 선택 |
| Kaggle SMS Spam Collection Dataset | SMS spam/ham 라벨 데이터셋. Kaggle은 로그인/API 토큰이 필요할 수 있음 | UCI 공개 미러 다운로드 스크립트 제공 |
| APICK 전체상품목록 | URL HTML 추출, URL 화면 캡처, URL 유사도 비교, WHOIS 등 기능 확인 | 악성 URL 확장 백로그 |
| Naver Android SMS 가져오기 | Android에서 `Telephony.Sms`/Cursor로 SMS 목록을 읽는 흐름 참고 | 모바일 연동 메모에 반영 |
| Hugging Face `nhagar/fineweb_urls` | `url`, `domain` 컬럼을 가진 URL/domain 데이터셋 | 정상 URL/domain 특징 확장 후보 |
| DBpia `NODE12483530` | KoBERT 텍스트 특징 768차원 + URL 특징 10차원 + MLP, F1 0.989 보고 | 다음 연구 목표와 비교 기준으로 사용 |
| KISA 보호나라 보안공지 `nttId=72029` | 지원금 사칭, 스미싱, 악성 URL 클릭, 악성앱 설치, 개인정보 탈취 주의 | 위험 키워드와 경고문 설계 |
| Android Developers default handlers (`https://developer.android.com/guide/topics/permissions/default-handlers`) | `READ_SMS` 같은 권한 요청 전 기본 SMS 핸들러가 되어야 한다는 안내 확인 | 모바일 자동 감지 제한 사항 |
| Google Play SMS/Call Log policy (`https://support.google.com/googleplay/android-developer/answer/10208820`) | SMS/Call Log 권한은 기본 SMS/Phone/Assistant 핸들러 등 허용 용도 중심으로 제한됨 | 배포 전 정책 확인 필요 |
