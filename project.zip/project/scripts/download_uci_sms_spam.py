#!/usr/bin/env python3
"""Download the public UCI SMS Spam Collection as an optional baseline dataset.

The Kaggle page in the class notes refers to the same well-known SMS spam
corpus, but Kaggle often requires an account/API token. This script uses the
public UCI mirror so the class prototype can be reproduced with one command.
"""

from __future__ import annotations

import argparse
import csv
import io
import zipfile
from pathlib import Path
from urllib.request import Request, urlopen

UCI_URL = "https://archive.ics.uci.edu/ml/machine-learning-databases/00228/smsspamcollection.zip"


def main() -> int:
    parser = argparse.ArgumentParser(description="Download UCI SMS Spam Collection")
    parser.add_argument("--url", default=UCI_URL)
    parser.add_argument("--out", type=Path, default=Path("data/sms_spam_uci.csv"))
    args = parser.parse_args()

    request = Request(args.url, headers={"User-Agent": "SWU-smishing-baseline/1.0"})
    raw = urlopen(request, timeout=30).read()
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        content = archive.read("SMSSpamCollection").decode("utf-8", errors="replace")

    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["text", "label", "source"])
        writer.writeheader()
        for line in content.splitlines():
            if not line.strip():
                continue
            label, text = line.split("\t", 1)
            writer.writerow(
                {
                    "text": text,
                    "label": "smishing" if label == "spam" else "ham",
                    "source": "uci_sms_spam_collection",
                }
            )

    print(f"saved {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
