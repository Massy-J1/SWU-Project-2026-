#!/usr/bin/env python3
"""Run the reproducible submission experiment and save evidence files."""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from train import load_records
from smishing_detector.features import extract_features
from smishing_detector.tfidf_model import TfidfCentroidModel, evaluate, stratified_split


DATA = [Path("data/smishing_seed_ko.csv")]
MODEL_OUT = Path("artifacts/smishing_tfidf_model.json")
METRICS_OUT = Path("reports/metrics.json")
FEATURE_TABLE_OUT = Path("reports/feature_table.csv")
SMISHING_SCREEN_OUT = Path("reports/result_screen_smishing.txt")
HAM_SCREEN_OUT = Path("reports/result_screen_ham.txt")
API_SAMPLE_OUT = Path("reports/api_response_sample.json")

SMISHING_SAMPLE = "[정부24] 피해 지원금 신청 대상. 오늘 마감, 신청서 작성 http://gov24-benefit.example"
HAM_SAMPLE = "[학교] 내일 연구활동은 오후 2시에 시작합니다. 필기도구를 준비하세요."


def render_screen(message: str, prediction: dict) -> str:
    verdict = "위험: 스미싱 의심" if prediction["label"] == "smishing" else "정상 가능성 높음"
    lines = [
        "=== Smishing Guard 결과 화면 ===",
        f"판정: {verdict}",
        f"위험점수: {prediction['risk_score']:.2f}",
        f"임계값: {prediction['threshold']:.2f}",
        f"메시지 SHA-256: {prediction['features']['message_sha256']}",
        "근거:",
    ]
    reasons = prediction["features"]["reasons"]
    if reasons:
        lines.extend(f"- {reason}" for reason in reasons)
    else:
        lines.append("- 강한 위험 특징 없음")
    if prediction["label"] == "smishing":
        lines.append("경고: 출처가 불분명한 링크를 누르지 말고 공식 앱/사이트에서 직접 확인하세요.")
    lines.append("")
    lines.append("원문은 개인정보 보호를 위해 결과 파일에 저장하지 않음")
    return "\n".join(lines)


def save_feature_table(records: list[tuple[str, str]]) -> None:
    FEATURE_TABLE_OUT.parent.mkdir(parents=True, exist_ok=True)
    fields = [
        "sha256",
        "label",
        "url_count",
        "has_url",
        "has_non_https_url",
        "has_short_url",
        "has_suspicious_url_shape",
        "has_org_keyword",
        "has_urgency",
        "has_action_request",
        "has_app_install_request",
        "has_pii_request",
        "has_money",
        "has_phone",
        "reason_count",
    ]
    with FEATURE_TABLE_OUT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for text, label in records:
            features = extract_features(text)
            row = {
                "sha256": features["message_sha256"],
                "label": label,
                "url_count": features["url_count"],
                "reason_count": len(features["reasons"]),
            }
            row.update(features["flags"])
            writer.writerow(row)


def main() -> int:
    records = load_records(DATA)
    train_records, test_records = stratified_split(records, test_size=0.30, seed=42)
    model = TfidfCentroidModel.train(train_records, min_df=1, threshold=0.55)
    metrics = evaluate(model, test_records)
    metrics.update(
        {
            "n_total": len(records),
            "n_train": len(train_records),
            "n_test": len(test_records),
            "data_files": [str(path) for path in DATA],
            "threshold": 0.55,
            "submission_note": "한국어 합성 seed 라벨셋으로 만든 첫 MVP 실험 결과",
        }
    )

    MODEL_OUT.parent.mkdir(parents=True, exist_ok=True)
    METRICS_OUT.parent.mkdir(parents=True, exist_ok=True)
    model.save(MODEL_OUT)
    METRICS_OUT.write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8")
    save_feature_table(records)

    smishing_prediction = model.predict(SMISHING_SAMPLE)
    ham_prediction = model.predict(HAM_SAMPLE)
    SMISHING_SCREEN_OUT.write_text(render_screen(SMISHING_SAMPLE, smishing_prediction), encoding="utf-8")
    HAM_SCREEN_OUT.write_text(render_screen(HAM_SAMPLE, ham_prediction), encoding="utf-8")

    api_sample = {
        "request": {"message": "<원문은 앱에서 전송, 로그에는 저장하지 않음>"},
        "response": {
            "label": smishing_prediction["label"],
            "risk_score": smishing_prediction["risk_score"],
            "threshold": smishing_prediction["threshold"],
            "message_sha256": smishing_prediction["features"]["message_sha256"],
            "reasons": smishing_prediction["features"]["reasons"],
            "flags": smishing_prediction["features"]["flags"],
            "url_count": smishing_prediction["features"]["url_count"],
        },
    }
    API_SAMPLE_OUT.write_text(json.dumps(api_sample, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"model: {MODEL_OUT}")
    print(f"metrics: {METRICS_OUT}")
    print(f"feature table: {FEATURE_TABLE_OUT}")
    print(f"result screens: {SMISHING_SCREEN_OUT}, {HAM_SCREEN_OUT}")
    print("metrics:", json.dumps(metrics, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
