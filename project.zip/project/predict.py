#!/usr/bin/env python3
"""Predict one SMS message with the trained baseline model."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from smishing_detector.tfidf_model import TfidfCentroidModel


def main() -> int:
    parser = argparse.ArgumentParser(description="Run smishing detection for one message")
    parser.add_argument("message", nargs="*", help="SMS body. If omitted, stdin is used.")
    parser.add_argument("--model", type=Path, default=Path("artifacts/smishing_tfidf_model.json"))
    parser.add_argument("--json", action="store_true", help="Print raw JSON")
    args = parser.parse_args()

    if not args.model.exists():
        print(f"model not found: {args.model}", file=sys.stderr)
        print("run: python3 train.py", file=sys.stderr)
        return 2

    message = " ".join(args.message).strip() or sys.stdin.read().strip()
    if not message:
        print("empty message", file=sys.stderr)
        return 2

    model = TfidfCentroidModel.load(args.model)
    result = model.predict(message)

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0

    risky = result["label"] == "smishing"
    verdict = "위험: 스미싱 의심" if risky else "정상 가능성 높음"
    print(f"판정: {verdict}")
    print(
        "위험점수: {risk:.2f} (모델 {model:.2f}, 규칙 {rules:.2f}, 임계값 {threshold:.2f})".format(
            risk=result["risk_score"],
            model=result["model_probability"],
            rules=result["heuristic_score"],
            threshold=result["threshold"],
        )
    )
    print(f"메시지 SHA-256: {result['features']['message_sha256']}")

    reasons = result["features"]["reasons"]
    if reasons:
        print("근거:")
        for reason in reasons:
            print(f"- {reason}")
    else:
        print("근거: 강한 위험 특징 없음")

    if risky:
        print("경고문: 출처가 불분명한 링크를 열지 말고, 공식 앱/사이트에서 직접 확인하세요.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
