#!/usr/bin/env python3
"""Small JSON API for the smishing detector.

This is intentionally dependency-free so it can run on a school PC, a laptop,
or a small cloud VM without installing a web framework first.
"""

from __future__ import annotations

import argparse
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from smishing_detector.tfidf_model import TfidfCentroidModel


class SmishingApiHandler(BaseHTTPRequestHandler):
    model: TfidfCentroidModel | None = None

    def _json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/health":
            self._json(
                200,
                {
                    "status": "ok",
                    "model_loaded": self.model is not None,
                    "service": "smishing-detector",
                },
            )
            return
        self._json(404, {"error": "not_found", "message": "Use GET /health or POST /predict"})

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        if path != "/predict":
            self._json(404, {"error": "not_found", "message": "Use POST /predict"})
            return
        if self.model is None:
            self._json(503, {"error": "model_not_loaded"})
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length > 20_000:
                self._json(413, {"error": "payload_too_large"})
                return
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            message = str(payload.get("message", "")).strip()
            if not message:
                self._json(400, {"error": "empty_message"})
                return
        except json.JSONDecodeError:
            self._json(400, {"error": "invalid_json"})
            return

        result = self.model.predict(message)
        public_result = {
            "label": result["label"],
            "risk_score": result["risk_score"],
            "threshold": result["threshold"],
            "message_sha256": result["features"]["message_sha256"],
            "reasons": result["features"]["reasons"],
            "flags": result["features"]["flags"],
            "url_count": result["features"]["url_count"],
        }
        self._json(200, public_result)

    def log_message(self, fmt: str, *args) -> None:
        print("%s - %s" % (self.address_string(), fmt % args))


def main() -> int:
    parser = argparse.ArgumentParser(description="Run smishing detector JSON API")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--model", type=Path, default=Path("artifacts/smishing_tfidf_model.json"))
    args = parser.parse_args()

    if not args.model.exists():
        raise SystemExit(f"model not found: {args.model}. Run: python3 train.py")

    SmishingApiHandler.model = TfidfCentroidModel.load(args.model)
    server = ThreadingHTTPServer((args.host, args.port), SmishingApiHandler)
    print(f"serving http://{args.host}:{args.port}")
    print("endpoints: GET /health, POST /predict")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nshutting down")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
