# AI 시대의 스미싱·악성 URL 탐지 시스템

문자 1건을 입력하면 `스미싱 의심/정상 가능성`과 판단 근거를 출력하는 첫 베이스라인 모델입니다. 오늘 제출용 범위는 모바일 앱 완성이 아니라, 모바일 앱에 넣기 전 검증할 수 있는 테스트 모델과 실험 기록입니다.

## MVP

문자 메시지 1건 입력 → URL/기관사칭/긴급성/개인정보 요구/앱 설치 유도 특징 추출 → TF-IDF 베이스라인 판단 → 경고 문구 출력

## 파일 구성

| 경로 | 내용 |
|---|---|
| `smishing_detector/features.py` | regex 기반 특징 추출, URL 형태 분석, SHA-256 해시 |
| `smishing_detector/tfidf_model.py` | 외부 라이브러리 없는 TF-IDF centroid 분류 모델 |
| `train.py` | CSV 라벨셋 학습, 평가, 모델 저장 |
| `predict.py` | 문자 1건 예측 및 경고 화면 출력 |
| `api_server.py` | 모바일 앱이 호출할 수 있는 JSON 예측 API |
| `data/smishing_seed_ko.csv` | 한국어 스미싱/정상 합성 seed 라벨셋 |
| `scripts/download_uci_sms_spam.py` | 선택 자료: UCI SMS Spam 공개 데이터 다운로드 |
| `scripts/run_experiment.py` | 제출용 실험 결과 파일 자동 생성 |
| `mobile/android_kotlin_sample/` | Android 앱에서 API를 호출하는 Kotlin 샘플 |
| `mobile/smishing_guard_android/` | 폰에 설치해서 실험할 오프라인 Android 앱 |
| `docs/feature_schema.md` | 특징 스키마 표 |
| `docs/experiment_log.md` | 실험 로그, 성공/실패/막힌점 |
| `docs/mobile_app_integration.md` | Python 모델을 모바일 앱으로 연결하는 방법 |
| `docs/api_contract.md` | Android ↔ Python API 요청/응답 형식 |
| `docs/sources_summary.md` | 참고 자료 정리 |
| `reports/metrics.json` | 학습 평가 지표 |
| `reports/result_screen_*.txt` | 결과 화면 예시 |

## 실행 방법

Python 3만 있으면 됩니다. 현재 버전은 `scikit-learn`, `pandas`, `torch` 없이 동작합니다.

```bash
python3 train.py
```

예측:

```bash
python3 predict.py "[정부24] 피해 지원금 신청 대상. 오늘 마감 http://gov24-benefit.example"
```

JSON 출력:

```bash
python3 predict.py --json "[택배] 주소 오류로 배송 보류. 즉시 http://delivery-check.example 확인"
```

제출용 결과 파일 한 번에 생성:

```bash
python3 scripts/run_experiment.py
```

모바일 앱 연동용 API 실행:

```bash
python3 train.py
python3 api_server.py --host 127.0.0.1 --port 8000
```

API 테스트:

```bash
curl -s -X POST http://127.0.0.1:8000/predict \
  -H 'Content-Type: application/json' \
  -d '{"message":"[정부24] 피해 지원금 신청 대상. 오늘 마감 http://gov24-benefit.example"}'
```

선택: 공개 영어 SMS spam 데이터 추가

```bash
python3 scripts/download_uci_sms_spam.py
python3 train.py --data data/smishing_seed_ko.csv data/sms_spam_uci.csv
```

## 개인정보 보호

실험 로그에는 문자 원문 대신 `SHA-256` 해시를 남깁니다. 실제 문자, 전화번호, 계좌번호, URL 원문은 제출 자료에 저장하지 않는 것이 원칙입니다.

## 모바일 앱

`mobile/smishing_guard_android/`에 폰에서 직접 실행할 Android 앱을 추가했습니다. 서버 없이 APK 안의 모델을 사용합니다.

이미 생성된 APK:

```text
mobile\smishing_guard_android\app\build\outputs\apk\debug\app-debug.apk
```

기능:

- 문자 붙여넣기 분석
- 새 SMS 자동 감지
- 위험 문자 수신 시 알림 경고
- 원문 외부 전송 없음

빌드/설치 방법은 [mobile/smishing_guard_android/README.md](/mnt/c/Users/ogh00/Desktop/work/SWU_project/mobile/smishing_guard_android/README.md)를 보세요.

폰 실험 순서만 빠르게 보려면 [docs/android_usage.md](/mnt/c/Users/ogh00/Desktop/work/SWU_project/docs/android_usage.md)를 보세요.
